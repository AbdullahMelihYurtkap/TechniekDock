<html> 
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="<?php echo base_url("style/css/bootstrap.css"); ?>">
    <script type="text/javascript" src="<?php echo base_url("style/js/bootstrap.js"); ?>"></script>
</head>
<body>
	<div class="container-fluid">
	<div class="jumbotron">
	<a href="<?php echo base_url(); ?>index.php/login/index" class="btn btn-secondary btn-lg active" role="button" style="float: right;" aria-pressed="true">Admin</a>