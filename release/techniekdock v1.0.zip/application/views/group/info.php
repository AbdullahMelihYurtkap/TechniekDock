<div class="jumbotron">
<nav class="nav">
  <a class="nav-link" href="<?php echo site_url('group') ?>">Home</a>
  <a class="nav-link active" <a href=""> Informatie </a>
  <a class="nav-link" href="#">Link</a>
  <a class="nav-link disabled" href="#">Disabled</a>
</nav>


<h1>Some information about the webapp</h1>

<p>Details in here</p>