<div class="jumbotron">
  <h1 class="display-3">Hallo, leerlingen!</h1>
  <p class="lead">Vandaag krijgen jullie een rondleiding in het duurzaamheidsfabriek!</p>
  <hr class="my-4">
  <p>Om te beginnen maken we een groep aan om mee te kunnen doen met de Quizz!</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="<?php echo base_url(); ?>index.php/group/create_group" role="button">Let's go!</a>

  </p>
