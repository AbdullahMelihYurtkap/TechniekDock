

</div>

	<div class="jumbotron jumbotron-influid">
		<p class="lead">copyrights © 2017 TechniekDock</p> 
  	</div>

  	<script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>


  
</body>

</html>